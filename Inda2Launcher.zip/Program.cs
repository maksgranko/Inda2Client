﻿using System;
using System.CodeDom.Compiler;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Inda2Launcher
{
    internal class Program
    {
        [STAThread]
        static void Main()
        {
            using (var client = new WebClient())
            {
                //client.DownloadFile("https://github.com/maksgranko/Inda2Client/raw/main/Inda2.dll", "Inda2.dll");
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Inda2.MainForm());
            //var compiler = CodeDomProvider.CreateProvider("CSharp");
            //var parameters = new CompilerParameters
            //{
            //    CompilerOptions = "/t:library",
            //    GenerateInMemory = true,
            //    IncludeDebugInformation = false
            //};
            //var _sourceCode = File.ReadAllText("code.txt");
            //CompilerResults results = compiler.CompileAssemblyFromSource(parameters, _sourceCode);
            //var instance = results.CompiledAssembly.CreateInstance("Test.TestClass");
            //results.CompiledAssembly.GetType("Test.TestClass").GetMethod("TestMethod").Invoke(null, null);
            Thread.Sleep(9999);
        }
    }
}
